"""SQLAlchemy models for PostgreSQL database"""
from sqlalchemy import Column, String, Integer, Float, DateTime, Boolean, Text, ForeignKey, Enum, JSON, Index
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.database import Base
import enum
import uuid
from datetime import datetime

# Enums
class UserRole(str, enum.Enum):
    PATIENT = "patient"
    DOCTOR = "doctor"
    ADMIN = "admin"
    RECEPTIONIST = "receptionist"
    PHARMACY = "pharmacy"


class TokenStatus(str, enum.Enum):
    PENDING = "pending"
    WAITING = "waiting"
    CONFIRMED = "confirmed"
    IN_QUEUE = "in_queue"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    RESCHEDULED = "rescheduled"
    SKIPPED = "skipped"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    UNPAID = "unpaid"
    PAID = "paid"
    FAILED = "failed"
    CANCELLED = "cancelled"

class PaymentMethod(str, enum.Enum):
    ONLINE = "online"
    RECEPTION = "reception"


class DoctorStatus(str, enum.Enum):
    AVAILABLE = "available"
    BUSY = "busy"
    OFFLINE = "offline"
    ON_LEAVE = "on_leave"


class HospitalStatus(str, enum.Enum):
    OPEN = "open"
    CLOSED = "closed"
    MAINTENANCE = "maintenance"


# User Model
class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=True)
    phone = Column(String(20), unique=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default="patient", index=True) # Added index for role-based filtering
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=True, index=True) # Added index for hospital staff lookup
    location_access = Column(Boolean, default=False)
    date_of_birth = Column(String(20), nullable=True)
    gender = Column(String(20), nullable=True)
    address = Column(String(500), nullable=True)
    mrn_by_hospital = Column(JSON, default=dict) # Added for MRN tracking
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True) # Added index for user reporting
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    # Avatar stored as public URL (Cloudflare R2 or other S3-compatible storage)
    avatar_url = Column(String(500), nullable=True)
    avatar_mime = Column(String(100), nullable=True)
    avatar_updated_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    tokens = relationship("Token", back_populates="patient")
    activities = relationship("ActivityLog", back_populates="user")


# Hospital Model
class Hospital(Base):
    __tablename__ = "hospitals"

    id = Column(String, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    address = Column(String(500), nullable=False)
    city = Column(String(100), nullable=False)
    state = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=False)
    email = Column(String(255), nullable=True)
    rating = Column(Float, nullable=True)
    review_count = Column(Integer, default=0)
    status = Column(String(20), default="open", index=True) # Added index for open/closed filtering
    specializations = Column(JSON, default=list)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True) # Added index for hospital listing
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    doctors = relationship("Doctor", back_populates="hospital")


# Doctor Model
class Doctor(Base):
    __tablename__ = "doctors"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=True, index=True) # Added index for doctor profile lookup
    name = Column(String(100), nullable=False, index=True) # Added index for name search
    specialization = Column(String(100), nullable=False, index=True) # Added index for specialization filtering
    subcategory = Column(String(100), nullable=True, index=True) # Added index for detailed filtering
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=False, index=True)
    email = Column(String(255), nullable=True)
    rating = Column(Float, nullable=True)
    review_count = Column(Integer, default=0)
    consultation_fee = Column(Float, nullable=False)
    session_fee = Column(Float, nullable=True)
    has_session = Column(Boolean, default=False)
    pricing_type = Column(String(20), default="standard")
    status = Column(String(20), default="available", index=True) # Added index for availability filtering
    available_days = Column(JSON, default=list)
    start_time = Column(String(10), nullable=False)
    end_time = Column(String(10), nullable=False)
    avatar_initials = Column(String(10), nullable=True)
    patients_per_day = Column(Integer, default=10)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True) # Added index for doctor listing
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    hospital = relationship("Hospital", back_populates="doctors")
    tokens = relationship("Token", back_populates="doctor")


# Token Model
class Token(Base):
    __tablename__ = "tokens"

    id = Column(String, primary_key=True, index=True)
    patient_id = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    doctor_id = Column(String, ForeignKey("doctors.id"), nullable=False, index=True)
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=False, index=True)
    mrn = Column(String(50), nullable=True, index=True) # Added index for MRN lookup
    token_number = Column(Integer, nullable=False)
    hex_code = Column(String(20), nullable=False, index=True) # Added index for unique code lookup
    display_code = Column(String(20), nullable=True)
    appointment_date = Column(DateTime(timezone=True), nullable=False, index=True) # Added index for date filtering
    status = Column(String(20), default="pending", index=True) # Added index for status filtering
    payment_status = Column(String(20), default="pending", index=True) # Added index for payment status
    payment_method = Column(String(20), nullable=True) # Using string for DB compatibility, validated by PaymentMethod enum
    queue_position = Column(Integer, nullable=True)
    total_queue = Column(Integer, nullable=True)
    estimated_wait_time = Column(Integer, nullable=True)
    consultation_fee = Column(Float, nullable=True)
    session_fee = Column(Float, nullable=True)
    total_fee = Column(Float, nullable=True)
    department = Column(String(100), nullable=True, index=True)  # Added index for department filtering
    # Skip message scheduling
    pending_skip_task_id = Column(String(255), nullable=True)
    skipped_at = Column(DateTime(timezone=True), nullable=True)
    idempotency_key = Column(String(255), nullable=True, index=True) # Added index for idempotency check
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True) # Added index for token history
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Embedded snapshots
    doctor_name = Column(String(100), nullable=True)
    doctor_specialization = Column(String(100), nullable=True)
    doctor_avatar_initials = Column(String(10), nullable=True)
    hospital_name = Column(String(200), nullable=True)
    patient_name = Column(String(100), nullable=True)
    patient_phone = Column(String(20), nullable=True)
    patient_age = Column(Integer, nullable=True)
    patient_gender = Column(String(20), nullable=True)
    reason_for_visit = Column(Text, nullable=True)
    consultation_notes = Column(Text, nullable=True)

    # Status/Confirmation Tracking
    queue_opt_in = Column(Boolean, default=False)
    queue_opted_in_at = Column(DateTime(timezone=True), nullable=True)
    confirmed = Column(Boolean, default=False)
    confirmation_status = Column(String(50), nullable=True)
    confirmed_at = Column(DateTime(timezone=True), nullable=True)
    cancelled_at = Column(DateTime(timezone=True), nullable=True)
    called_at = Column(DateTime(timezone=True), nullable=True)
    started_at = Column(DateTime(timezone=True), nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    duration_minutes = Column(Float, nullable=True)

    # Doctor leave management fields
    doctor_unavailable = Column(Boolean, default=False)
    doctor_unavailable_reason = Column(String(255), nullable=True)
    leave_action = Column(String(100), nullable=True)
    suggested_doctor_id = Column(String, nullable=True)
    suggested_doctor_name = Column(String(100), nullable=True)
    rescheduled_at = Column(DateTime(timezone=True), nullable=True)
  
    #Rating
    is_rated = Column(Boolean, default=False)   # True once patient submits a rating
    rating = Column(Integer, nullable=True)    # 1–5, copied from DoctorRating on submit
    # Relationships
    patient = relationship("User", back_populates="tokens")
    doctor = relationship("Doctor", back_populates="tokens")
    payments = relationship("Payment", back_populates="token")


# Hospital Sequence for MRN and other numbering
class HospitalSequence(Base):
    __tablename__ = "hospital_sequences"
    
    id = Column(String, primary_key=True, index=True)
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=False, unique=True)
    mrn_seq = Column(Integer, default=0)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

# Payment Model
class Payment(Base):
    __tablename__ = "payments"

    id = Column(String, primary_key=True, index=True)
    token_id = Column(String, ForeignKey("tokens.id"), nullable=False)
    amount = Column(Float, nullable=False)
    method = Column(String(20), nullable=False) # Using string for DB compatibility, validated by PaymentMethod enum
    status = Column(String(20), default="pending") # Using string for DB compatibility, validated by PaymentStatus enum
    transaction_id = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    token = relationship("Token", back_populates="payments")


# Activity Log Model
class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    activity_type = Column(String(50), nullable=False)
    description = Column(Text, nullable=False)
    meta_data = Column(JSON, nullable=True)  # Renamed from 'metadata' to avoid SQLAlchemy reserved name
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=True, onupdate=func.now())

    # Relationships
    user = relationship("User", back_populates="activities")


# Queue Model
class Queue(Base):
    __tablename__ = "queues"

    id = Column(String, primary_key=True, index=True)
    doctor_id = Column(String, ForeignKey("doctors.id"), nullable=False)
    current_token = Column(Integer, nullable=True)
    waiting_patients = Column(Integer, default=0)
    estimated_wait_time_minutes = Column(Integer, nullable=True)
    people_ahead = Column(Integer, default=0)
    total_queue = Column(Integer, default=0)
    # Queue pause fields for doctor leave management
    paused = Column(Boolean, default=False)
    queue_paused = Column(Boolean, default=False)
    queue_pause_reason = Column(String(255), nullable=True)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


# Idempotency Record Model
class IdempotencyRecord(Base):
    __tablename__ = "idempotency_records"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, nullable=False)
    key = Column(String(255), nullable=False)
    action = Column(String(100), nullable=False)
    token_id = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# Pharmacy Medicine Model
class PharmacyMedicine(Base):
    __tablename__ = "pharmacy_medicines"

    id = Column(String, primary_key=True, index=True)
    product_id = Column(Integer, nullable=False, index=True)
    batch_no = Column(String(50), nullable=False, index=True)
    name = Column(String(200), nullable=False, index=True)
    generic_name = Column(String(200), nullable=True, index=True)
    type = Column(String(100), nullable=True)
    distributor = Column(String(200), nullable=True)
    purchase_price = Column(Float, nullable=False)
    selling_price = Column(Float, nullable=False)
    stock_unit = Column(String(50), nullable=True)
    quantity = Column(Integer, default=0, index=True)
    expiration_date = Column(DateTime(timezone=True), nullable=True, index=True)
    category = Column(String(100), nullable=True, index=True)
    sub_category = Column(String(100), nullable=True, index=True)
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=True, index=True)
    is_deleted = Column(Boolean, default=False, index=True)
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), index=True)

    __table_args__ = (
        # Composite index for the most common query: filter by hospital + sort by updated_at
        Index('ix_pharmacy_medicines_hospital_updated', 'hospital_id', 'updated_at'),
    )


# Department Model
class Department(Base):
    __tablename__ = "departments"

    id = Column(String, primary_key=True, index=True)
    name = Column(String(100), nullable=False, index=True) # Added index for name search
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True) # Added index for listing


# Quick Action Model
class QuickAction(Base):
    __tablename__ = "quick_actions"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    action_type = Column(String(50), nullable=False)
    title = Column(String(100), nullable=False)
    description = Column(String(255), nullable=True)
    icon = Column(String(50), nullable=True)
    route = Column(String(255), nullable=True)
    is_enabled = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# Medical Record Model
class MedicalRecord(Base):
    __tablename__ = "medical_records"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_type = Column(String(100), nullable=False)
    file_size = Column(Integer, nullable=False)
    record_type = Column(String(50), default="general")
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


# Wallet Model
class Wallet(Base):
    __tablename__ = "wallets"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), unique=True, nullable=False)
    balance = Column(Float, default=0.0)
    currency = Column(String(10), default="PKR")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


# Refund Model
class Refund(Base):
    __tablename__ = "refunds"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    token_id = Column(String, ForeignKey("tokens.id"), nullable=False)
    amount = Column(Float, nullable=False)
    status = Column(String(20), default="pending")
    method = Column(String(50), nullable=False)
    reason = Column(String(255), nullable=True)
    transaction_id = Column(String(255), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


# Support Ticket Model
class SupportTicket(Base):
    __tablename__ = "support_tickets"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    subject = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(50), default="general")
    priority = Column(String(20), default="medium")
    status = Column(String(20), default="open")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class OTPVerification(Base):
    __tablename__ = "otp_verifications"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    phone = Column(String, nullable=False)
    otp = Column(String, nullable=False)
    is_used = Column(Boolean, default=False)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

# Pharmacy Sale Model
class PharmacySale(Base):
    __tablename__ = "pharmacy_sales"

    id = Column(String, primary_key=True, index=True)
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=True, index=True)
    patient_id = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    doctor_id = Column(String, ForeignKey("doctors.id"), nullable=True, index=True)
    medicine_id = Column(Integer, nullable=True)
    medicine_name = Column(String(200), nullable=True)
    quantity = Column(Integer, default=1)
    unit_price = Column(Float, nullable=True)
    total_price = Column(Float, nullable=True)
    total_amount = Column(Float, nullable=True)  # Used in POS
    items = Column(JSON, nullable=True)  # Used in POS for multiple items
    payment_status = Column(String(20), default="paid")
    sold_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    performed_by = Column(String, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Doctor Rating Model
class DoctorRating(Base):
    __tablename__ = "doctor_ratings"

    id                      = Column(String, primary_key=True, index=True)
    token_id                = Column(String, ForeignKey("tokens.id"), nullable=False, index=True)
    doctor_id               = Column(String, ForeignKey("doctors.id"), nullable=False, index=True)
    patient_id              = Column(String, ForeignKey("users.id"), nullable=False, index=True)
    rating                  = Column(Integer, nullable=False)        # 1–5
    review                  = Column(Text, nullable=True)
    # Snapshots — no extra joins needed in doctor portal
    patient_name            = Column(String(100), nullable=True)
    patient_avatar_initials = Column(String(10), nullable=True)
    appointment_date        = Column(DateTime(timezone=True), nullable=True)
    created_at              = Column(DateTime(timezone=True), server_default=func.now())
    updated_at              = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    token   = relationship("Token", backref="rating_obj")
    doctor  = relationship("Doctor", backref="ratings")
    patient = relationship("User", backref="given_ratings")

    __table_args__ = (
        # One rating per patient per token (appointment)
        Index("uq_token_patient_rating", "token_id", "patient_id", unique=True),
    )

# ═══════════════════════════════════════════════════════════
#  PHARMACY INVOICES
# ═══════════════════════════════════════════════════════════

class PharmacyInvoice(Base):
    __tablename__ = "pharmacy_invoices"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    invoice_number = Column(String, unique=True, nullable=False, index=True)
    customer_id = Column(String, nullable=True)
    customer_name = Column(String, nullable=False, default="Walk in customer")
    status = Column(String, default="pending", nullable=False, index=True)
    payment_method = Column(String, default="cash", nullable=False)
    subtotal = Column(Float, default=0.0)
    discount = Column(Float, default=0.0)
    discount_percent = Column(Float, default=0.0)
    tax = Column(Float, default=0.0)
    total = Column(Float, default=0.0)
    amount_paid = Column(Float, default=0.0)
    balance_due = Column(Float, default=0.0)
    notes = Column(Text, nullable=True)
    hospital_id = Column(String, ForeignKey("hospitals.id"), nullable=True, index=True)
    created_by = Column(String, nullable=True)
    is_deleted = Column(Boolean, default=False)
    deleted_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "invoice_number": self.invoice_number,
            "customer_id": self.customer_id,
            "customer_name": self.customer_name,
            "status": self.status,
            "payment_method": self.payment_method,
            "subtotal": self.subtotal,
            "discount": self.discount,
            "discount_percent": self.discount_percent,
            "tax": self.tax,
            "total": self.total,
            "amount_paid": self.amount_paid,
            "balance_due": self.balance_due,
            "notes": self.notes,
            "hospital_id": self.hospital_id,
            "created_by": self.created_by,
            "is_deleted": self.is_deleted,
            "deleted_at": self.deleted_at.isoformat() if self.deleted_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class PharmacyInvoiceItem(Base):
    __tablename__ = "pharmacy_invoice_items"

    id = Column(String, primary_key=True, index=True, default=lambda: str(uuid.uuid4()))
    invoice_id = Column(String, ForeignKey("pharmacy_invoices.id"), nullable=False, index=True)
    medicine_id = Column(String, nullable=True)
    product_id = Column(Integer, nullable=True)
    product_name = Column(String, nullable=False)
    product_code = Column(String, nullable=True)
    quantity = Column(Float, nullable=False, default=1)
    unit_price = Column(Float, nullable=False, default=0.0)
    discount = Column(Float, default=0.0)
    total = Column(Float, nullable=False, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "invoice_id": self.invoice_id,
            "medicine_id": self.medicine_id,
            "product_id": self.product_id,
            "product_name": self.product_name,
            "product_code": self.product_code,
            "quantity": self.quantity,
            "unit_price": self.unit_price,
            "discount": self.discount,
            "total": self.total,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
